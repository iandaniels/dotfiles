Use like any other minor mode.  You'll see tooltips with dates
instead of Unix epoch times.  This mode turns on font-lock and
leaves it on forever.  You may or may not like that.
