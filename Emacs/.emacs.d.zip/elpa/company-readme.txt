Company is an Emacs extension for performing text completion.
Completion candidates are retrieved from a variety of modular
back-ends, such as Semantic.

Once installed, enable company-mode with M-x company-mode.
For further information, see the docstring for `company-mode'.
