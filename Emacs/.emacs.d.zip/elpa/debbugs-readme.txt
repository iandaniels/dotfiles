This package provides some basic functions to access a debbugs SOAP
server (see <http://wiki.debian.org/DebbugsSoapInterface>).

It implements the SOAP functions "get_bugs", "newest_bugs",
"get_status" and "get_bug_log".  The SOAP functions "get_usertag" and
"get_versions" are not implemented (yet).

The debbugs server to be connected can be customized via the option
`debbugs-port'.
