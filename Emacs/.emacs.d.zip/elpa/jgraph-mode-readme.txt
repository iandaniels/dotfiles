Simple editing mode for the Jgraph graph plotting tool.
You can find more info at http://web.eecs.utk.edu/~plank/plank/jgraph/jgraph.html
