Usage:
  (require 'flymake-ruby)
  (add-hook 'ruby-mode-hook 'flymake-ruby-load)

Uses flymake-easy, from https://github.com/purcell/flymake-easy
