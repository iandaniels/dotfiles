SiSU (http://www.sisudoc.org/) is a document structuring and
publishing framework.  This package provides an Emacs major mode
for SiSU markup.

When this package is installed, files ending in ".sisu" are
automatically associated with sisu-mode.  If a file doesn't have a
.sisu extension, add a first line:
# -*- Sisu -*-

The documentation for the "Structure Of The Hierarchy Text" can be
found in the sisustring for the sisu-mode function.
